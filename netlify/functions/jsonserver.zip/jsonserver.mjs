
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/jsonserver/jsonserver.mjs
var jsonserver_default = (request, context) => {
  try {
    const url = new URL(request.url);
    const subject = url.searchParams.get("name") || "World";
    return new Response(`Hello ${subject}`);
  } catch (error) {
    return new Response(error.toString(), {
      status: 500
    });
  }
};
export {
  jsonserver_default as default
};
